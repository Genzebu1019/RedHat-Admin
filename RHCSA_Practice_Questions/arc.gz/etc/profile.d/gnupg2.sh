export GPG_TTY=$(tty)
